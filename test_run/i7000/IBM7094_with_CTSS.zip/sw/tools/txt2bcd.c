/***********************************************************************
*
* txt2bcd.c - IBM 7090 Text to BCD converter.
*
* Changes:
*   ??/??/??   PRP   Original.
*   01/28/05   DGP   Changed to use IBSYS standard characters as default.
*   03/18/05   DGP   Changed 072 usage, in altbcd it is a '?'.
*   01/03/06   DGP   Added alternate BCD support.
*   04/13/06   DGP   Added '~' as alternate eof char.
*   05/31/06   DGP   Added simh format support and blocking.
*   10/24/06   DGP   Remove length mask in tapewriteint.
*   03/19/07   DGP   Correct alternate BCD EBCDIC translation
*                    and include parity tables directly.
*   
***********************************************************************/


#include <stdlib.h>
#include <stdio.h>

#include "sysdef.h"

#define MAXREC 32768

char fin[300], fon[300];

static int altchars;
static int simhfmt;
static int reclen;
static int blklen;
static int chrcnt;
static int chrblk;

#include "parity.h"
#include "tobcd.h"

static char datbuf[MAXREC];

/***********************************************************************
* tapewriteint - Write an integer.
***********************************************************************/

static void
tapewriteint (FILE *fd, int v)
{
   fputc (v & 0xFF, fd);
   fputc ((v >> 8) & 0xFF, fd);
   fputc ((v >> 16) & 0xFF, fd);
   fputc ((v >> 24) & 0xFF, fd);
}

/***********************************************************************
* mapchar - Map char to BCD and even parity.
***********************************************************************/

static int
mapchar (int ch)
{
   return evenpar[altchars ? toaltbcd[ch] : tobcd[ch]];
}

/***********************************************************************
* padrec - Pad out record to length.
***********************************************************************/

static void
padrec (char pad)
{
   char ch;

   while (chrcnt < reclen)
   {
      ch = mapchar (pad);

      if (!simhfmt && chrblk == 0)
	 ch |= 0200;
      datbuf[chrblk++] = ch;
      chrcnt++;
   }
   chrcnt = 0;
}

/***********************************************************************
* padblk - Pad out block to length.
***********************************************************************/

static void
padblk (FILE *fo, char pad, int truncate)
{
   char ch;

   if (truncate)
   {
      if (simhfmt) tapewriteint (fo, chrblk);
      fwrite (datbuf, 1, chrblk, fo);
      if (simhfmt) tapewriteint (fo, chrblk);
      chrblk = 0;
      return;
   }

   while (chrblk < blklen)
   {
      ch = mapchar (pad);

      if (!simhfmt && chrblk == 0)
	 ch |= 0200;
      datbuf[chrblk++] = ch;
   }

   chrblk = 0;
   if (simhfmt) tapewriteint (fo, blklen);
   fwrite (datbuf, 1, blklen, fo);
   if (simhfmt) tapewriteint (fo, blklen);
}

/***********************************************************************
* dofile - Process file names.
***********************************************************************/

static void
dofile (char *arg, char *fn, char *ex)
{
   int extfnd = FALSE;

   while (*arg)
   {
      if (*arg == '.') extfnd = TRUE;
      *fn++ = *arg++;
   }

   if (!extfnd)
   {
      *fn++ = '.';
      while (*ex) *fn++ = *ex++;
   }
   *fn = '\0';
}

/***********************************************************************
* parsefiles - Parse the files and add extensions with defaults.
***********************************************************************/

void
parsefiles (int argc, char **argv, char *iex, char *oex, int *parm1, int *parm2)
{
   int i;
   char *f1p, *f2p;
   char *p1p, *p2p;

   f1p = f2p = p1p = p2p = NULL;

   if (argc < 2 || argc > 5 || (parm1 == 0 && argc > 3) ||
   	(parm2 == 0 && argc > 4))
   {
   USAGE:
      if (parm1 == 0)
      {
         fprintf (stderr, "Usage: %s2%s infile [outfile]\n",
		  iex, oex);
      }
      else if (parm2 == 0)
      {
         fprintf (stderr,
		  "Usage: %s2%s infile [outfile] [reclen, default %d]\n",
		  iex, oex, *parm1);
      }
      else
      {
         fprintf (stderr,
   "Usage: %s2%s infile [outfile] [reclen, default %d [blklen, default %d]]\n",
		  iex, oex, *parm1, *parm2);
      }
      exit (1);
   }

   for (i = 1; i < argc; i++)
   {
      char *cp;
      int alldigits = TRUE;

      cp = argv[i];
      while (*cp) 
      {
         if (!isdigit (*cp))
	 {
	    alldigits = FALSE;
	    break;
	 }
	 cp++;
      }
      if (alldigits)
      {
         if (!p1p) p1p = argv[i];
	 else if (!p2p) p2p = argv[i];
	 else goto USAGE;
      }
      else
      {
         if (!f1p) f1p = argv[i];
	 else if (!f2p) f2p = argv[i];
	 else goto USAGE;
      }
   }

   if (f1p) dofile (f1p, fin, iex);
   else     goto USAGE;
   if (f2p) dofile (f2p, fon, oex);
   else     dofile (f1p, fon, oex);
   if (p1p && parm1) *parm1 = atoi (p1p);
   if (p2p && parm2) *parm2 = atoi (p2p);

}


/***********************************************************************
* main - Main procedure.
***********************************************************************/

int
main (int argc, char **argv)
{
   FILE *fi, *fo;
   char *optarg;
   int optind;
   int c;

   altchars = FALSE;
   simhfmt = FALSE;

   for (optind = 1, optarg = argv[optind];
       (optind < argc) && (*optarg == '-');
       optind++, optarg = argv[optind])
   {
      ++optarg;
      while (*optarg)
      {
         switch (*optarg++)
	 {

         case 's':
	    simhfmt = TRUE;
	    /* Fall through */

         case 'a':
            altchars = TRUE;
            break;

         default:
            fprintf (stderr,
	     "Usage: txt2bcd [-options] infile [outfile] [reclen [blklen]]]\n");
            fprintf (stderr, "  -a     Use Alternate character set\n");
            fprintf (stderr, "  -s     Use simh format\n");
            exit (1);
         }
      }
   }

   reclen = 80;
   blklen = 84;

   parsefiles (argc - (optind-1), &argv[optind-1], "txt", "bcd",
	       &reclen, &blklen);

   if ((fi = fopen (fin, "r")) == NULL)
   {
      perror (fin);
      exit (1);
   }
   if ((fo = fopen (fon, "wb")) == NULL)
   {
      perror (fon);
      exit (1);
   }

   chrcnt = 0;
   chrblk = 0;

   while ( (c = fgetc (fi)) != EOF )
   {
      if (c == '\r') ;
      else if (c == '\n')
      {
	 padrec (' ');
	 if (chrblk + reclen > blklen)
	    padblk (fo, 0, 0);
      }
      else if (c == '\f' || c == '~')
      {
	 if (chrblk) padblk (fo, 0, 1);
	 if (!simhfmt) fputc (0217, fo);
	 else          tapewriteint (fo, 0);
      }
      else if (c == '\t')
      {
	 c = mapchar (' ');
         if (!simhfmt && chrblk == 0)
	    c |= 0200;
	 datbuf[chrblk++] = c;
         chrcnt++;

	 c &= 0177;
         while (chrcnt % 8 != 0)
	 {
	    datbuf[chrblk++] = c;
            chrcnt++;
         }
      }
      else
      {
	 c = mapchar (c);
         if (!simhfmt && chrblk == 0)
	    c |= 0200;
	 datbuf[chrblk++] = c;
         chrcnt++;
      }
   }

   if (chrcnt > 0)
   {
      padrec (' ');
   }
   if (chrblk > 0)
   {
      padblk (fo, 0, 1);
   }

   if (simhfmt)
   {
      tapewriteint (fo, 0);
      tapewriteint (fo, 0);
   }
   else
   {
      fputc (0217, fo);
      fputc (0217, fo);
   }
   return (0);
}
