
http://sky-visions.com/ibm/ibm704_soft.shtml


To SAP run:
    run mkbcdtape to build sysin.tp of assembly source. 
Blocking must be set to 1 line/record. Or the input can be read from the
card reader.

    mkbcdtape -b1 -o sysin.tp xxxx.sap

    attach cr0 -f cbn uatapeload.dck or uadrumload.dck
    boot cr0
    \<at halt job is done\>

Tapes:
    Bin tape     A1
    Out tape	 A2
    Input tape   A3
    Library tape A4
    temp Tape	 A5
    Scratch tape A0

  The listing will be on tape A2 and or printer depending on setting of
Switch 5.
     
Switches:
Switch 1 - 1 read tape A3  - 0 read card reader
Switch 2 - ?
Switch 3 - 1 don't print to sysprinter, 0 print to sysprinter
Switch 4 - Not used.
Switch 5 - 1 write listing to A2, - 0 don't write to A2


To reload the SAP tape or load SAP onto the drum, use the following load
deck:

    1) Loader deck.     ualtpsap.dck or ualdrsap.dck
    2) Control card.    In ualtpsap.dck & ualdrsap.dck
    3) Pass 1,2,3.      In ualtpsap.dck & ualdrsap.dck

uasap_split.sh creates these tapes from the output of the assembly.

The output from the assembly is the following deck.

File:
    Card 1: Drum loader;
    Card 2: Drum control card;
    Card 3: Tape Loader;
    Card 4: Tape Control card;
    Card 5: Find END or FIN on input tape
    Card 6-23: Loader deck;
    Card 24-*: Main program

Use cr0 for the i704 simulator or cr3 for the i7090 simulator in i704 mode.

To load from deck to tape or drum:
    attach cr0 -f cbn ualtpsap.dck or ualdrsap.dck
    boot cr0
    \<At first halt\>
    go 6231
    \<at second halt load is complete\>
   

Thanks go to Paul Pierce for making the SHARE tapes available. This program
can be found on tape adc00037.bcd. And to Paul McJones for scanning the
SAP manual.

