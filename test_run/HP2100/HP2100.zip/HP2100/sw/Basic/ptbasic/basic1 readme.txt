
http://rikers.org/hp2100/jeff/hpbasic/index.html

HP BASIC Paper Tapes 

hpbasic.abs	HP BASIC SYSTEM                   BINARY   20392-60001 REV B  
prepare.abs	PREPARE BASIC SYSTEM              BINARY   20392-60002 REV B  
basic1.abs	CONFIGURED BASIC 20392            TTY 11   MYLAR              


Lanzar con:

   hp2100 basic1.ini

	READY
	10 PRINT SQR(2)
	20 END
	RUN
	 1.41421


The program is a complete but early BASIC and has one unsual requirement:
all programs must include a valid END statement to run correctly.  

Exit with BYE basic commando

