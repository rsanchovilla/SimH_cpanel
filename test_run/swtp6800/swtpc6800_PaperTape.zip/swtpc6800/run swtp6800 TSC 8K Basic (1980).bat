@echo off
cd sw
cd "basic"

..\swtp6800mp-a bas8k.ini 
