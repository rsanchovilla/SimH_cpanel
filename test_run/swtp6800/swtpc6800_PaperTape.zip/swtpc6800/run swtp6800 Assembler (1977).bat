@echo off

cd sw
cd "asm"
..\swtp6800mp-a asmb.ini 
