@echo off

cd sw
cd "MAsm10"
..\swtp6800mp-a asmb_swtpc.ini Source/ASM_Sample.ASM  Work/ASM_Sample.S19  0100

