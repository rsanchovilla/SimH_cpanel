@echo off
cd sw
cd "other\SpaceVoyage"
..\..\swtp6800mp-a spacev.ini 
