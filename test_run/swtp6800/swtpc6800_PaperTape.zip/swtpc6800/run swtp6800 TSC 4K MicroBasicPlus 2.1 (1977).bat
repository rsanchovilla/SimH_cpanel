@echo off
cd sw
cd "basic"
..\swtp6800mp-a bas.ini 
