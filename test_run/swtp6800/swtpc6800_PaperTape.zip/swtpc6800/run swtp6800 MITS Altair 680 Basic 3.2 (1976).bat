@echo off
cd sw
cd "msbas"

..\swtp6800mp-a bas.ini 
