@echo off

cd sw
cd "asm"
..\swtp6800mp-a debug.ini 
