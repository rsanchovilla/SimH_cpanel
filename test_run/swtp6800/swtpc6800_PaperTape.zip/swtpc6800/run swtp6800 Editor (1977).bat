@echo off

cd sw
cd "asm"
..\swtp6800mp-a edit.ini 
