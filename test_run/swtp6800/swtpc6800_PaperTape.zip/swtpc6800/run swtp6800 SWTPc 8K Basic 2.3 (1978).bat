@echo off
cd sw
cd "swtpcbas"

..\swtp6800mp-a bas23.ini 
