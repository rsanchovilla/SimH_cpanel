@echo off

cd sw
cd "MAsm10"
..\swtp6800mp-a asmb_exorciser.ini

