@echo off
cd sw
cd "swtpcbas"

..\swtp6800mp-a bas20_4k.ini 
