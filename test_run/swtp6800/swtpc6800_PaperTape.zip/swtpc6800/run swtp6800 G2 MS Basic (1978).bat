@echo off
cd sw
cd "msbas"

..\swtp6800mp-a g2bas.ini 
