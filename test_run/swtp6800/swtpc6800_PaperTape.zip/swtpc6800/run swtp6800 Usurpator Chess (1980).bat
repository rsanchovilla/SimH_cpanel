@echo off
cd sw
cd "other\chess"
..\..\swtp6800mp-a Usurpator.ini 
