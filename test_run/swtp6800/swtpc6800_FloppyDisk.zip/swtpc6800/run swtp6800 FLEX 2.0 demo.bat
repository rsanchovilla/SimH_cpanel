@echo off
cd sw
cd "Flex20"
..\swtp6800mp-a flex20_demo.ini
