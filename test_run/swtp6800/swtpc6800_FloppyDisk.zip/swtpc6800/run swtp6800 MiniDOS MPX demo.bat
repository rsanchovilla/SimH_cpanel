@echo off

cd sw
cd "minidos"
..\swtp6800mp-a MiniDOS_MPX_demo.ini

