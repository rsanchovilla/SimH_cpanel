@echo off

cd sw
cd "fdos"
..\swtp6800mp-a FDOS_demo.ini

