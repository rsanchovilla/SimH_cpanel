@echo off
cd sw
cd "dos68"
..\swtp6800mp-a dos68.ini
