@echo off
cd sw
cd "cp68"
..\swtp6800mp-a cp68.ini
