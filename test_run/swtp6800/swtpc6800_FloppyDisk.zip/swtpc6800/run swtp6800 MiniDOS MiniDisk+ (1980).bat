@echo off

cd sw
cd "minidos"
..\swtp6800mp-a MiniDisk.ini

