@echo off
cd sw
cd "Flex10"
..\swtp6800mp-a flex10.ini
