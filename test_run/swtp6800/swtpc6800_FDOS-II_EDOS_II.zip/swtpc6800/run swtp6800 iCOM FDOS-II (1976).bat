@echo off

cd sw
cd "fdos-ii"
..\swtp6800mp-a FDOS-II.ini

