@echo off

cd sw
cd "edos-ii"
..\swtp6800mp-a EDOS-II_build.ini

