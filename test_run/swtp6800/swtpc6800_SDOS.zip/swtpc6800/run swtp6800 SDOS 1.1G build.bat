@echo off
cd sw
cd "sdos"
..\swtp6800mp-a sdos_build.ini
