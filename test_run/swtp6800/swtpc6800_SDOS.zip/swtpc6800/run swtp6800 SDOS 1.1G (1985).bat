@echo off
cd sw
cd "sdos"
..\swtp6800mp-a sdos.ini
