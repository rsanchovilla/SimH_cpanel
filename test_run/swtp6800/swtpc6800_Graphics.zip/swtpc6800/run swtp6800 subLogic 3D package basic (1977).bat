@echo off
cd sw
cd "other\subLogic_3D_bas"
..\..\swtp6800mp-a SubLogic_3D_test2_bas.ini
