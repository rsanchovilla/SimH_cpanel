@echo off
cd sw
cd "other\gt6144"
..\..\swtp6800mp-a ST1.ini
