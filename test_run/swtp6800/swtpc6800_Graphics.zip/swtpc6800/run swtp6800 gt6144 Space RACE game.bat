@echo off
cd sw
cd "other\gt6144"
..\..\swtp6800mp-a SWT_Space_RACE.ini
