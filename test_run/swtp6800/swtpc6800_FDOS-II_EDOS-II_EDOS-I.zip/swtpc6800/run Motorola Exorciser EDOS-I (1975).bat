@echo off

cd sw
cd "edos-i"
..\swtp6800mp-a EDOS-I.ini

