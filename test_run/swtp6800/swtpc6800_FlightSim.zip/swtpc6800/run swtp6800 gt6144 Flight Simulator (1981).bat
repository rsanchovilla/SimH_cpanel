@echo off
cd sw
cd "other\FlightSim"
..\..\swtp6800mp-a FlightSim_m6800.ini
