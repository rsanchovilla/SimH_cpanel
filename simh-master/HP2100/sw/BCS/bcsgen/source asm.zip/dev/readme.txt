
  Vintage HP21xx Minicomputer Tools
  =================================

This directory contains source code and "new" binaries for the vintage
SIO drivers, assembler, ALGOL and FORTRAN compilers, BCS prepare program
and library and various BCS drivers. Also includes an experimental TTY driver
that works with a normal terminal that sends only CR when enter is pressed.

The asm files are assembly source code
The hpbin directory contains ABS and REL binaries
The hpscripts directory contains utility bash scripts

The original source code was obtained from BitSavers under the
/bits/HP/tapes/matureActiveRootSet_15Jan81/ directory (tape1 and tape2).

sioptr.asm   abs 20319-80001_A (one segment)          SIO PTR driver
sioptp.asm   abs 20320-80001_A (one segment)          SIO PTP driver
siotty.asm   abs 24127-80001_A (one segment)          SIO TTY driver
siodump.asm  abs 20335-80001_B (one segment)          SIO dump utility
extasmb.asm  abs 24031-80001_B through 24031-80005_B  Non-EAU assembler
algol.asm    abs 24044-80001_B through 24044-80012_B  ALGOL compiler
fortran1.asm abs 20548-80001_A through 20548-80011_A  FORTRAN compiler pass 1
fortran2.asm abs 20548-80012_A through 20548-80015_A  FORTRAN compiler pass 2
bcsprep.asm  abs 20021-80001_C through 20021-80005_C  BCS prepare program
bcslib.asm   rel 24146-80001_B through 24146-80010_B  BCS library
bcstty.asm   rel 20017-80001_C (one segment)          BCS TTY driver
bcsttycr.asm rel -----------------------------------  Modified BCS TTY driver
bcsptr.asm   rel 20005-80001_B (one segment)          BCS PTR driver
bcsptp.asm   rel 20006-80001_1430 (one segment)       BCS PTP driver
bcsioc.asm   rel 24173-80001_A (one segment)          BCS I/O control module
bcsloadr.asm rel 20018-80001_1430 th 20018-80004_1430 BCS loader module

The source files are from magtape images and have bit 7 "randomly" set,
a utility must be used to clear bit 7 of all bytes, I used the StripAll
script and a simple HP-IPL/OS utility to do this. Afterwards the resulting
plain-text segments were appended together using the cat command, then I
edited the source files so that the ASMB directive is on the first line
for neatness (extasmb doesn't care). Other blank lines in the source
files are from joining the segments. The bcslib.asm source required
special treatment as it contains 76 ASMB segments and the papertape
version of extasmb can only assemble one segment at a time, and all
segments must be assembled to the same binary without leaders/trailers
between the segments. To solve this problem I used a script that shells
a simple BASIC program that splits up the source file on ASMB boundaries
then assembles them all separately to a single file, setting a switch
option that suppresses leader/trailer generation. To avoid issues in
certain circumstances, a 16-byte leader and trailer was manually added.

The bcsttycr.asm/rel driver is an edited version of the BCS TTY driver to
avoid having to switch to CRLF enters or press control-MJ when using apps
linked using BCS. It does scary stuff like directly outputting a LF when
it receives a CR, has not been fully tested long-term, but seems to work.

A preconfigured 16KW SIO driver is provided in the sio.abs binary,
configured for TTY=11, PTR=12, PTP=13. See sio_config.txt for the config
procedure. It seems to work but it has not been well-tested. In case there
is an issue the well-worn SIO driver I've been using for a few years is in
the sio_old.abs binary (same configuration), derived from the sio16k11.abs
file. The TTY portion of the code is different, see sio_dump_old.txt and
sio_dump.new.txt. One behavior difference is the new driver properly
outputs page feeds in assembly listings etc.

Preconfigured 31KW BCS "linkers" are provided in the bcs31k.abs and
bcs31k_stock.abs binaries, bcs31k.abs contains the modified TTY driver.
Both are set the same as the SIO drivers, TTY=11, PTR=12, PTP=13.
See bcs31k_prep_*.txt for the config procedures.


Using the tools under SimH hp2100
---------------------------------

Set the I/O assignments...

set clk dev=10
set tty dev=11
set ptr dev=12
set ptp dev=13

To assemble an assembly source file... (only one ASMB segment allowed)
(replace source module and output with the actual filenames)

d s 0
d 0-77777 0
load sio.abs
load extasmb.abs
attach -e ptr source.asm
attach ptp module.rel (or output.abs if ASMB,A)
run 100
[does pass 1]
attach -e ptr source.asm
c
[does pass 2]
detach ptp

To compile an ALGOL source file...

d s 0
d 0-77777 0
load sio.abs
load algol.abs
attach -e ptr source.alg
attach ptp module.rel
run 100
[compiles]
detach ptp

To compile a FORTRAN source file...

d s 0
d 0-77777 0
load sio.abs
load fortran1.abs
attach -e ptr source.ftn
attach ptp tempfile
run 100
[does pass 1]
load fortran2.abs
attach -e ptr tempfile
attach ptp module.rel
run 100
[does pass 2]
detach ptp

To link modules to an ABS application...

d 0-77777 0
load bcs31k.abs
attach -e ptr module1.rel
attach ptp output.abs
d s 40000
run 2
[prompts *LOAD]
attach -e ptr module2.rel  [if multiple modules]
c                          [if multiple modules]
[prompts *LOAD]            [if multiple modules]
[repeat until all modules loaded]
attach -e ptr bcslib.rel
d s 40004
c
[prompts *LST]
c
[prompts *END] [if it hangs control-e to halt]
detach ptp
d s 0

Some of the steps aren't strictly necessary every time, don't need to
clear S (the switch register) if it's already clear, don't need to detach
ptp if careful not to write more to the file, and it's not always necessary
to d 0-77777 0 (clear memory) but clearing ensures that traces of previous
runs don't cause issues. If the B register is not clear when running BCS it
hangs when it gets to the END prompt instead of halting, and the generated
code is slightly different (the resulting app halts at an address two
instructions higher but otherwise functions OK). Papertape software was
originally loaded using the "BBL", which clears the A and B registers after
loading. It appears that if B is not clear, BCS assumes it was loaded from
another system. In the 31K config, on start it jumps to location 73235...

73235:  LIA 1
73236:  SZB
73237:  LDB 73277
73240:  SZB
73241:  STB 214,I

...first it gets the switch register bits, and if B is not clear, loads B
from location 73277 (which contains 114106, or JSB 106,I) and stores it in
the address specified by location 214 (which contains 74055), which is the
address BCS jumps to when it gets to END. Location 106 contains 0 so it
executes from location 1 and goes on a wild code chase, unless either B
is clear when starting BCS, or location 106 points to an exit sub.

-------------------------------------------------
Terry Newton (wtn90125@yahoo.com)
Last modified June 9, 2011

